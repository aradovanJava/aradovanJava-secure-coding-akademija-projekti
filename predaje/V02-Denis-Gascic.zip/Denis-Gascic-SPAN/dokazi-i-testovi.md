# Evidencija sigurnosnih testova – MedTermin V02

Svi nazivi i ishodi u ovoj tablici temelje se na testnim klasama i izlazima koje je polaznik dostavio tijekom rada. Za predaju treba spremiti završni Surefire izvještaj (`target/surefire-reports/`) i puni `mvnw clean test` ispis.

| ID nalaza | Klasa / test | Prije popravka (RED) | Nakon popravka (GREEN) |
|---|---|---|---|
| N-01 | `NalaziAutorizacijaSigurnosniTest.neispravanFormatNeZaobilaziProvjeruVlasnistva` | očekivano 404, dobiveno 200 | Polaznik potvrdio prolaz nakon popravka. |
| N-02 | `ResetLozinkeSigurnosniTest.predvidiviTokenNeOmogucujeResetLozinke` | očekivano 400, dobiveno 200 | Polaznik potvrdio prolaz nakon popravka. |
| N-03 | `LijecniciSqlInjectionSigurnosniTest.proizvoljniSqlIzrazZaSortiranjeSeOdbija` | očekivano 400, dobiveno 200 | Polaznik potvrdio prolaz nakon popravka. |
| N-04 | `CorsSigurnosniTest.nedopusteniOriginSeOdbija` | očekivano 403, dobiveno 204 | Polaznik potvrdio prolaz nakon popravka. |
| N-05 | `IspisStoredXssSigurnosniTest.napomenaNeSmijeSadrzavatiIzvrsiviHtml` | odgovor sadržavao sirovi script | Polaznik potvrdio prolaz nakon popravka. |
| N-06 | `SigurnostLogiranjaTest.lozinkaSeNeSmijeZapisivatiULog` | sentinel pronađen u CapturedOutput | Polaznik potvrdio prolaz nakon popravka. |
| N-07 | `SnakeYamlSigurnosniTest.proizvoljniJavaTipoviSeOdbijaju` | očekivano 400, dobiveno 200 | Polaznik potvrdio prolaz nakon popravka. |
| N-08 | `RezervacijaBrisanjeSigurnosniTest.drugiKorisnikNeMozeObrisatiTuduRezervaciju` | očekivano 404, dobiveno 204 | Polaznik potvrdio prolaz nakon popravka. |
| N-09 | `LozinkaHasherSigurnosniTest.istaLozinkaMoraImatiRazliciteHashVrijednosti` | dva hasha su identična | Polaznik potvrdio prolaz nakon popravka. |

## Zajednički regresijski testovi

- Početni baseline: 43 testa, 0 failures, 0 errors, 0 skipped (prije dodavanja sigurnosnih testova).
- Nakon dodavanja sigurnosnih testova i nadogradnje Spring Boota polaznik je prijavio da svi testovi prolaze.
- Točan završni broj `Tests run`, `Failures`, `Errors` i `Skipped` nije dostavljen; ne navodi se izmišljeni broj.
- Funkcionalni testovi u paketu `funkcionalno` nisu namjerno mijenjani, prema zahtjevu projekta.

## Napomena o ponovljivosti

Nakon popravaka i nadogradnje ovisnosti pokrenuti iz konačne lokalne mape `java/`:

```powershell
.\mvnw.cmd clean test
```

Spremiti `target/surefire-reports/*.txt` i završni konzolni sažetak u `alati/poslije/`. Testovi moraju se izvršavati na JDK 21 (Temurin 21.0.13), ne na JDK 27, zbog ranije uočenog problema kompatibilnosti JaCoCo 0.8.13.