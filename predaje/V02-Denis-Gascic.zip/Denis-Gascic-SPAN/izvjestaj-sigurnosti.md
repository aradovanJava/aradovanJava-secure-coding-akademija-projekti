# Izvještaj o sigurnosnoj analizi i popravcima

**Secure Coding akademija · Tjedan 2 · Projekt V02 – MedTermin**

> **Status dokumenta:** dovršena radna verzija na temelju početnog projektnog ZIP-a i rezultata koje je polaznik dostavio u razgovoru. Prije predaje potrebno je popuniti osobne podatke, dodati stvarne izvoze alata i provjeriti izvještaj nad konačnom lokalnom kopijom koda. ZIP izvorno dostavljen u razgovoru sadrži početno stanje, ne konačne izmijenjene Java datoteke.

## Podaci o projektu

| Polje | Vrijednost |
|---|---|
| Polaznik | **Upisati ime i prezime** |
| Varijanta | V02 |
| Tehnologija | Java 21, Spring Boot 4.1.2, Maven Wrapper, H2 |
| Datum izvještaja | 15. 11. 2026. |
| Moodle savjeti | Nije evidentirano u dostupnim bilješkama; polaznik treba potvrditi stvarno korištenje. |
| AI asistenti | ChatGPT korišten kao pomoć pri analizi koda, oblikovanju testnih scenarija, interpretaciji rezultata alata i sastavljanju dokumentacije. Polaznik je izvršavao naredbe i provjere u lokalnom okruženju. |

## 1. Sažetak

U varijanti V02 aplikacije MedTermin analizirano je devet namjerno ugrađenih ranjivosti u Java/Spring Boot implementaciji. Za svaku je izrađen zaseban sigurnosni test koji je na ranjivom stanju reproducirao problem (RED), a nakon izmjene koda korisnik je potvrdio prolaz (GREEN). Najvažniji nalazi bili su neovlašten pristup i brisanje tuđih zapisa, predvidiv reset token, SQL injection, Stored XSS, nesigurna YAML deserijalizacija i slabo hashiranje lozinki. Snyk Open Source završno je testirao 50 ovisnosti i prijavio **0 ranjivih putanja**. Polaznik je potvrdio da svi testovi prolaze, ali završni broj testova i postotak JaCoCo pokrivenosti nisu dostavljeni te se zato ne navode kao brojčano potvrđeni.

| Pronađene ugrađene ranjivosti | Ispravljene | Sigurnosni testovi RED → GREEN | Snyk završno | JaCoCo pokrivenost |
|---:|---:|---:|---:|---|
| 9 | 9 | 9 | 0 ranjivih putanja / 50 ovisnosti | Nije zabilježen postotak; dopuniti iz konačnog `target/site/jacoco/index.html` |

## 2. Opseg i metodologija

Analiza je provedena nad lokalnom aplikacijom `http://localhost:8080`, bez izlaganja namjerno ranjive aplikacije javnoj mreži. Korišteni su ručni pregled Java koda, Bruno za ručne HTTP zahtjeve, OWASP ZAP za početni DAST pregled, Snyk Open Source CLI za SCA i JUnit/Spring Boot Test za dokazivanje ranjivosti i popravaka. JaCoCo 0.8.13 bio je konfiguriran i početni izvještaj generiran, ali završni postotak pokrivenosti nije zabilježen. SAST rezultat (Semgrep ili SpotBugs/Find Security Bugs) nije dostavljen i ostaje otvorena stavka projekta.

| Alat | Vrsta | Rezultat / dokaz | Ograničenje evidencije |
|---|---|---|---|
| OWASP ZAP | DAST | Početni Automatic Scan nad `http://localhost:8080`; zabilježeni su nedostajući CSRF tokeni, CSP, anti-clickjacking i X-Content-Type-Options. | Nije priložen HTML/JSON izvoz ni završni scan nakon popravaka. |
| Bruno | Ručno DAST/API testiranje | Reproducirani zahtjevi za nalaze, reset token, sortiranje, CORS preflight, Stored XSS i brisanje rezervacije. | Verzija alata i izvozi kolekcije nisu dostavljeni. |
| Snyk Open Source CLI | SCA | Prvo 19 ranjivosti / 19 putanja; nakon nadogradnji **50 ovisnosti testirano, 0 ranjivih putanja**. | Snyk CLI verzija nije zabilježena; završni JSON treba spremiti u `alati/poslije/`. |
| Maven Dependency Plugin | SCA pomoćna provjera | Potvrđene razriješene verzije Spring Boot 4.1.2, Jackson 3.1.8, Jackson 2.21.8 (test scope) i SnakeYAML 2.6. | Potpuni konačni dependency tree treba spremiti kao tekstualni dokaz. |
| JUnit 5 / Spring Boot Test | Sigurnosno i funkcionalno testiranje | Devet zasebnih sigurnosnih testova; polaznik je potvrdio da svi testovi prolaze. | Završni Surefire sažetak s ukupnim brojem testova nije dostavljen. |
| JaCoCo 0.8.13 | Pokrivenost | Izvještaj je generiran u `target/site/jacoco/`. | Nema potvrđenog postotka linijske pokrivenosti nakon posljednjih izmjena. |
| Semgrep ili SpotBugs | SAST | Nije potvrđen izvršeni SAST scan. | Obavezno pokrenuti i spremiti SARIF/XML/tekstualni rezultat prije predaje. |

## 3. Nalazi i popravci

### N-01: Zaobilaženje autorizacije nalaza zbog pogrešno obrađene iznimke

| Polje | Opis |
|---|---|
| Kategorija | A01:2025 – Broken Access Control; povezana kategorija A10:2025 – Mishandling of Exceptional Conditions · CWE-862 (Missing Authorization) / CWE-755 (Improper Handling of Exceptional Conditions) |
| Lokacija | GET /api/nalazi/{id}?format=…; NalazController.java, metoda nalaz(). |
| Kako je pronađeno | Ručni pregled + Bruno; sigurnosni test NalaziAutorizacijaSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Kao Ana (KORISNIK) poslati GET /api/nalazi/2?format=xyz s Aninim Bearer tokenom. Prije popravka API je vratio 200 OK i Markov nalaz. Kontrolni zahtjev bez neispravnog formata vraćao je „Nalaz nije pronađen.”. |
| Uzrok | Provjera vlasništva bila je unutar try bloka nakon Format.valueOf(). Neispravna vrijednost izazvala je IllegalArgumentException, catch je obradio grešku formata i preskočio provjeru vlasništva. |
| Popravak | Format se parsira sigurno (Format.procitaj); provjera vlasništva izvršava se neovisno o formatu i prije prikaza sadržaja. Nepoznat format može dobiti zadani JSON prikaz samo nakon uspješne autorizacije. |
| Test | NalaziAutorizacijaSigurnosniTest.neispravanFormatNeZaobilaziProvjeruVlasnistva — prije: očekivano 404, dobiveno 200; nakon: korisnik je potvrdio prolaz. |
| Potvrda | Bruno reprodukcija i sigurnosni test. Nije dostavljen zaseban završni ZAP izvještaj. |
| Preporuka | Autorizaciju postaviti prije parsiranja formata i izvan catch bloka koji obrađuje ulaz. Dodati negativne testove za svaki format i ulogu. |

### N-02: Predvidiv i neograničen token za obnovu lozinke

| Polje | Opis |
|---|---|
| Kategorija | A07:2025 – Authentication Failures; povezana kategorija A04:2025 – Cryptographic Failures · CWE-640 (Weak Password Recovery Mechanism) / CWE-330 (Insufficiently Random Values) |
| Lokacija | POST /api/auth/reset-zahtjev i POST /api/auth/reset; ResetLozinkeService.java, metode zatrazi() i postaviNovuLozinku(). |
| Kako je pronađeno | Ručni pregled + reprodukcija u PowerShellu/Brunu; ResetLozinkeSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Za testnog korisnika zatražen je reset. Token iz lokalne datoteke pošte bio je jednak MD5(username + yyyy-MM-dd), izračunatom neovisno u PowerShellu: b633a7014b0d6f030b79dc796a67c4da. Prije popravka izračunati token prihvaćen je za promjenu lozinke (HTTP 200). |
| Uzrok | Token je bio deterministički MD5 sažetak javno poznatog korisničkog imena i datuma. U tablici reset_tokeni nije se provjeravao rok valjanosti ni iskorištenost tokena. |
| Popravak | SecureRandom generira 32 slučajna bajta; u bazi se sprema SHA-256 sažetak tokena, izvorni token šalje se lokalnom poštanskom sandučiću; token istječe nakon 30 minuta i atomski se označuje iskorištenim unutar transakcije. |
| Test | ResetLozinkeSigurnosniTest.predvidiviTokenNeOmogucujeResetLozinke — prije: očekivano 400, dobiveno 200; nakon: korisnik je potvrdio prolaz. |
| Potvrda | Test prije/poslije i ručna usporedba tokena. U završnom izvještaju ne objavljivati stvarne tokene. |
| Preporuka | Koristiti kriptografski sigurne nasumične tokene, čuvati samo njihov sažetak, postaviti TTL, jednokratnu uporabu i ograničenje zahtjeva za reset. |

### N-03: SQL Injection kroz parametar sortiranja liječnika

| Polje | Opis |
|---|---|
| Kategorija | A05:2025 – Injection · CWE-89 (Improper Neutralization of Special Elements used in an SQL Command) |
| Lokacija | GET /api/lijecnici?sort=…&smjer=…; LijecnikController.java, metoda popis(). |
| Kako je pronađeno | Ručni pregled + Bruno; LijecniciSqlInjectionSigurnosniTest. |
| Ozbiljnost | **Srednja** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | S Aninim tokenom poslati sort=CASE WHEN 1=1 THEN ime ELSE prezime END i smjer=asc. Prije popravka odgovor 200 OK bio je poredan po imenu, što potvrđuje da je SQL izraz izvršen unutar ORDER BY. Automatizirani test očekivao je 400, a dobio 200. |
| Uzrok | Vrijednosti sort i smjer izravno su konkatenirane u SQL tekst. SQL parametri ne mogu parametrizirati naziv stupca ili ključnu riječ ASC/DESC, pa je nužna allowlist provjera. |
| Popravak | Dopušteni stupci: ime, prezime, specijalizacija; dopušteni smjerovi: asc, desc. U SQL se umeću samo konstante iz switch/allowlist grana, nikad sirovi korisnički unos. |
| Test | LijecniciSqlInjectionSigurnosniTest.proizvoljniSqlIzrazZaSortiranjeSeOdbija — prije: očekivano 400, dobiveno 200; nakon: korisnik je potvrdio prolaz. |
| Potvrda | Bruno test promjene redoslijeda + sigurnosni test; funkcionalni test liječnika zadržan. |
| Preporuka | Za dinamičke SQL identifikatore koristiti allowlist, za vrijednosti bind parametre; ne pokušavati parametrizirati nazive stupaca. |

### N-04: Preširoka CORS politika prihvaća proizvoljan Origin

| Polje | Opis |
|---|---|
| Kategorija | A02:2025 – Security Misconfiguration · CWE-942 (Permissive Cross-domain Policy with Untrusted Domains) / CWE-346 (Origin Validation Error) |
| Lokacija | CORS filter; CorsFilter.java, metoda dopusten(); preflight OPTIONS zahtjevi. |
| Kako je pronađeno | OWASP ZAP + Bruno + ručni pregled; CorsSigurnosniTest. |
| Ozbiljnost | **Srednja** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | OPTIONS /api/ja s Origin: https://evil.example, Access-Control-Request-Method: GET i Access-Control-Request-Headers: authorization. Prije popravka odgovor je uključivao Access-Control-Allow-Origin: https://evil.example i Access-Control-Allow-Credentials: true; sigurnosni test dobio je 204 umjesto očekivanog 403. |
| Uzrok | Metoda dopusten() provjeravala je samo počinje li Origin s http:// ili https://, iako je konfigurirana lista dopuštenih origina postojala. |
| Popravak | Origin se prihvaća samo ako je točno sadržan u konfiguriranoj allowlisti app.cors.allowed-origins. Nepoznati preflight origin dobiva 403. |
| Test | CorsSigurnosniTest.nedopusteniOriginSeOdbija — prije: očekivano 403, dobiveno 204; nakon: korisnik je potvrdio prolaz. CorsFunkcionalniTest zadržan. |
| Potvrda | Bruno preflight test za zlonamjerni origin i funkcionalni test dopuštenog localhost:5173 origina. |
| Preporuka | CORS postaviti na najmanji nužni popis originâ. CORS nije zamjena za autentifikaciju, autorizaciju ni CSRF zaštitu. |

### N-05: Stored Cross-Site Scripting u HTML potvrdi rezervacije

| Polje | Opis |
|---|---|
| Kategorija | A05:2025 – Injection · CWE-79 (Improper Neutralization of Input During Web Page Generation) |
| Lokacija | GET /ispis/rezervacije/{id}; IspisController.java, HTML generiranje potvrde; napomena rezervacije. |
| Kako je pronađeno | Bruno + ručni pregled + IspisStoredXssSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Kreirana je testna rezervacija s napomenom <script>alert(1)</script>. GET /ispis/rezervacije/3 vratio je sirovi element <script> unutar <dd> u HTML dokumentu. |
| Uzrok | Vrijednosti pacijenta, liječnika, naziva/napomene umeću se u HTML bez kontekstualnog HTML escaping-a. |
| Popravak | Sva tekstualna polja koja se umeću u HTML obrađuju se s postojećom Html.escape() metodom. Korisnički sadržaj prikazuje se kao tekst, ne kao izvršivi markup. |
| Test | IspisStoredXssSigurnosniTest.napomenaNeSmijeSadrzavatiIzvrsiviHtml — prije: odgovor sadržavao sirovi script; nakon: sadrži &lt;script&gt;…&lt;/script&gt; i test prolazi. |
| Potvrda | Bruno pregled sirovog HTML odgovora i automatski test. |
| Preporuka | Escape na izlazu prema HTML kontekstu; ne oslanjati se samo na validaciju ulaza. Razmotriti CSP kao dodatnu, ne primarnu obranu. |

### N-06: Izlaganje lozinki i osobnih podataka u aplikacijskim logovima

| Polje | Opis |
|---|---|
| Kategorija | A09:2025 – Security Logging and Alerting Failures · CWE-532 (Insertion of Sensitive Information into Log File) |
| Lokacija | KorisnikService.java, prijava(); RezervacijaService.java, kreiraj(). |
| Kako je pronađeno | Ručni pregled Maven/JUnit logova; SigurnostLogiranjaTest. |
| Ozbiljnost | **Srednja** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Test prijave koristio je sentinel lozinku TEST-TAJNA-LOZINKA-73921. Prije popravka log je sadržavao cijeli PrijavaZahtjev objekt, uključujući password. Log rezervacije također je sadržavao cijeli NovaRezervacija objekt s OIB-om i napomenom. |
| Uzrok | Logger je zapisivao cijele DTO/record objekte koji sadrže tajne ili osobne podatke. |
| Popravak | Logira se samo korisničko ime i ID termina/rezervacije; lozinka, OIB i napomena ne serijaliziraju se u log poruci. |
| Test | SigurnostLogiranjaTest.lozinkaSeNeSmijeZapisivatiULog — prije: sentinel pronađen u CapturedOutput; nakon: korisnik je potvrdio prolaz. Rezervacijski zapis pregledan ručno nakon izmjene. |
| Potvrda | CapturedOutput JUnit test za lozinku; pregled log poruke rezervacije. |
| Preporuka | Ne logirati DTO objekte koji nose tajne/PII. Uvesti log redaction pravila i testove za osjetljive vrijednosti. |

### N-07: Nesigurna YAML deserijalizacija nepouzdanog zahtjeva

| Polje | Opis |
|---|---|
| Kategorija | A08:2025 – Software or Data Integrity Failures · CWE-502 (Deserialization of Untrusted Data) |
| Lokacija | POST /api/postavke; PostavkeController.java, metoda spremi(); SnakeYAML dependency. |
| Kako je pronađeno | Snyk SCA + ručni pregled + Bruno; SnakeYamlSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Authenticated POST /api/postavke s Content-Type: application/yaml i tijelom koje počinje s !!java.util.LinkedHashMap prihvaćen je prije popravka (HTTP 200); sigurnosni test očekivao je 400, a dobio 200. Ovaj test dokazuje prihvaćanje Java type taga, ne samostalno izvršavanje proizvoljnog koda. |
| Uzrok | Korišten je new Yaml().load(...) s ranjivom SnakeYAML 1.33 verzijom i bez sigurnog konstruktora. |
| Popravak | Korišten je SafeConstructor s LoaderOptions ograničenjima (duplicate keys, aliases, nesting depth, code point limit); SnakeYAML je nadograđen. Konačni dependency tree prikazuje SnakeYAML 2.6. |
| Test | SnakeYamlSigurnosniTest.proizvoljniJavaTipoviSeOdbijaju — prije: očekivano 400, dobiveno 200; nakon: korisnik je potvrdio prolaz. Obični YAML postavki ostaje podržan. |
| Potvrda | Sigurnosni test, funkcionalni PostavkeFunkcionalniTest i Maven dependency tree. |
| Preporuka | Koristiti safe constructor, strogu shemu/allowlist tipova, ograničiti veličinu i dubinu dokumenta te držati parser ažuriranim. |

### N-08: Korisnik može obrisati tuđu rezervaciju

| Polje | Opis |
|---|---|
| Kategorija | A01:2025 – Broken Access Control · CWE-862 (Missing Authorization) |
| Lokacija | DELETE /api/rezervacije/{id}; RezervacijaService.java, metoda obrisi(). |
| Kako je pronađeno | Ručni pregled + Bruno + RezervacijaBrisanjeSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Ana je kreirala rezervaciju. Marko je s vlastitim Bearer tokenom poslao DELETE /api/rezervacije/{id}. Prije popravka dobiven je 204 No Content; rezervacija je uklonjena. Test je očekivao 404, a dobio 204. |
| Uzrok | Metoda je dohvatila rezervaciju i izvršila DELETE bez usporedbe rezervacija.pacijent s prijavljenim korisnikom i bez administrativne iznimke. |
| Popravak | Prije bilo kakve izmjene provjerava se da je korisnik ADMIN ili vlasnik rezervacije. Za nedopušten pristup vraća se 404. Tek nakon provjere briše se rezervacija i smanjuje zauzeće termina. |
| Test | RezervacijaBrisanjeSigurnosniTest.drugiKorisnikNeMozeObrisatiTuduRezervaciju — prije: očekivano 404, dobiveno 204; nakon: korisnik je potvrdio prolaz. |
| Potvrda | Test provjerava status i da Anina rezervacija ostaje dostupna; funkcionalni test otkazivanja vlastite rezervacije zadržan. |
| Preporuka | Provjera vlasništva nad objektom u servisnom sloju za svaki read/update/delete endpoint; testirati uloge i vlasništvo zasebno. |

### N-09: Pohrana lozinki brzim SHA-256 sažetkom bez soli

| Polje | Opis |
|---|---|
| Kategorija | A04:2025 – Cryptographic Failures · CWE-916 (Use of Password Hash With Insufficient Computational Effort) |
| Lokacija | LozinkaHasher.java; hash() i provjeri(). |
| Kako je pronađeno | Ručni pregled + LozinkaHasherSigurnosniTest. |
| Ozbiljnost | **Visoka** – kvalitativna procjena utjecaja u kontekstu aplikacije; nije izračunat CVSS vektor. |
| Dokaz prije popravka | Dva uzastopna poziva hash("TestLozinka123!") vratila su identičan SHA-256 zapis afc101d2…abe4ce8b. Sigurnosni test očekivao je različite zapise, a dobio identične. |
| Uzrok | SHA-256 je deterministički i brz; nije korištena jedinstvena nasumična sol ni funkcija za derivaciju ključa namijenjena lozinkama. |
| Popravak | PBKDF2-HMAC-SHA256 s 600.000 iteracija, 16-bajtnom nasumičnom soli i 256-bitnim izlazom. Format pohrane uključuje algoritam, iteracije, sol i hash. Stari SHA-256 zapisi provjeravaju se radi kompatibilnosti i nadograđuju nakon uspješne prijave. |
| Test | LozinkaHasherSigurnosniTest.istaLozinkaMoraImatiRazliciteHashVrijednosti — prije: dva hasha su identična; nakon: različiti hashovi, oba provjeravaju istu lozinku, pogrešna lozinka se odbija. |
| Potvrda | Sigurnosni test i funkcionalni testovi autentikacije/registracije/promjene lozinke. |
| Preporuka | Koristiti Argon2id ili PBKDF2/bcrypt s jedinstvenom soli i parametrima prilagođenima produkcijskom hardveru; planirati migraciju legacy hashova. |

## 4. SCA – nadogradnja ovisnosti

Snyk je na stanju sa Spring Bootom 3.5.16 prijavio 19 problema u 19 ranjivih putanja, među ostalim za Jackson, Tomcat, Spring Framework, Logback, Hibernate Validator, Log4j i Spring Security Crypto. Nakon migracije na Spring Boot 4.1.2 i usklađivanja ovisnosti, Snyk je prijavio: **Tested 50 dependencies for known issues, no vulnerable paths found.** Posljednji zasebni Jackson 3 nalaz uklonjen je nadogradnjom `tools.jackson.core:jackson-databind` i `jackson-core` na 3.1.8. Mavenov dependency tree potvrdio je Jackson 3.1.8, Jackson 2.21.8 u testnom opsegu i SnakeYAML 2.6. Nula Snyk nalaza znači da u trenutku skeniranja nije postojala poznata ranjiva putanja u skeniranom Maven dependency grafu; to nije dokaz da je aplikacija bez svih mogućih ranjivosti.

| Komponenta | Potvrđena konačna verzija / stanje | Napomena |
|---|---|---|
| Spring Boot | 4.1.2 | Potvrđeno u Maven dependency treeju. |
| Spring Framework | 7.0.10 | Vidljivo u korisnički dostavljenom tree isječku. |
| Jackson 3 (runtime) | 3.1.8 | Potvrđeno. |
| Jackson 2 (test scope) | 2.21.8 | Dodan radi kompatibilnosti postojećih testova koji koriste `com.fasterxml.jackson.*`; nije runtime zamjena za Jackson 3. |
| SnakeYAML | 2.6 | Potvrđeno. |
| Ostale ovisnosti | Snyk završni rezultat: 0 ranjivih putanja | Za konačni prilog spremiti cjelovit dependency tree i JSON Snyk izvještaj. |

## 5. Početni DAST nalazi i otvorena opažanja

Početni ZAP pregled prikazao je sljedeće alert-e: Absence of Anti-CSRF Tokens (2 instance), Content Security Policy (CSP) Header Not Set (3), Missing Anti-clickjacking Header (3), X-Content-Type-Options Header Missing (4) i informativni Authentication Request Identified. Za CSRF je pregledan obrazac `POST /prijava` s poljima `username`, `password` i `returnUrl`; ZAP nije pronašao token. Nije provedena dokumentirana završna ZAP usporedba. CORS je popravljan zasebno, ali to ne rješava automatski CSRF ni nedostajuća sigurnosna zaglavlja.

**Otvorene stavke koje ne smiju biti prikazane kao riješene:**

1. Provesti ciljanu provjeru CSRF-a za web prijavu i druge cookie-authenticated POST/DELETE radnje; dodati CSRF zaštitu ili dokumentirati zašto endpoint nije izložen riziku.
2. Odrediti i postaviti CSP, `X-Frame-Options` ili CSP `frame-ancestors`, te `X-Content-Type-Options: nosniff`.
3. HSTS se ne može potvrditi na lokalnom HTTP-u; u produkciji je potreban TLS i HSTS na HTTPS odgovoru.
4. Ponoviti ZAP scan nakon popravaka i izvesti HTML report u `alati/poslije/zap.html`.
5. Pokrenuti barem jedan SAST alat (Semgrep ili SpotBugs/Find Security Bugs) nad konačnom Java mapom i spremiti rezultat.
6. Spremiti završni JaCoCo izvještaj i unijeti postotak pokrivenosti linija.

## 6. Model prijetnji

Aplikacija obrađuje autentifikacijske podatke, zdravstvene nalaze, rezervacije, OIB, datoteke, YAML postavke i zapise logiranja. Glavne granice povjerenja su preglednik/HTTP klijent prema API-ju, API prema H2 bazi, API prema datotečnom sustavu i lokalnom poštanskom sandučiću te API prema simuliranom bolničkom sustavu. STRIDE detalji i registar rizika nalaze se u zasebnom `model-prijetnji.md`.

## 7. OWASP ASVS 5.0.0

Zahtjevi ASVS-a popunjeni su u zasebnoj `asvs-kontrolna-lista.md`. Procjena je konzervativna: zahtjevi bez potvrđenog dokaza označeni su kao djelomični ili neispunjeni. Posebno su otvoreni CSP, produkcijski TLS/HSTS, formalni SBOM, autentikacijsko audit-logiranje i dovršetak alata SAST/DAST.

## 8. Testovi i pokrivenost

| Sigurnosni test | Nalaz | Prije | Nakon |
|---|---|---|---|
| `NalaziAutorizacijaSigurnosniTest.neispravanFormatNeZaobilaziProvjeruVlasnistva` | N-01 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `ResetLozinkeSigurnosniTest.predvidiviTokenNeOmogucujeResetLozinke` | N-02 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `LijecniciSqlInjectionSigurnosniTest.proizvoljniSqlIzrazZaSortiranjeSeOdbija` | N-03 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `CorsSigurnosniTest.nedopusteniOriginSeOdbija` | N-04 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `IspisStoredXssSigurnosniTest.napomenaNeSmijeSadrzavatiIzvrsiviHtml` | N-05 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `SigurnostLogiranjaTest.lozinkaSeNeSmijeZapisivatiULog` | N-06 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `SnakeYamlSigurnosniTest.proizvoljniJavaTipoviSeOdbijaju` | N-07 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `RezervacijaBrisanjeSigurnosniTest.drugiKorisnikNeMozeObrisatiTuduRezervaciju` | N-08 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |
| `LozinkaHasherSigurnosniTest.istaLozinkaMoraImatiRazliciteHashVrijednosti` | N-09 | RED – pad s dokazom navedenim u nalazu | GREEN – prolaz je potvrdio polaznik |

Početni funkcionalni baseline zabilježio je 43 testa bez neuspjeha. Nakon dodavanja sigurnosnih testova i migracije Spring Boota polaznik je potvrdio da svi testovi prolaze, ali nije dostavio završni Surefire sažetak. Točan završni broj testova zato nije naveden. JaCoCo 0.8.13 generirao je izvještaj; završni postotak linijske pokrivenosti nije dostavljen. Prije predaje otvoriti `target/site/jacoco/index.html`, zapisati ukupni `Lines Covered / Lines Missed` postotak i priložiti dokaz.

## 9. Zaključak

U analizi je pronađeno i popravljeno devet ranjivosti: dvije provjere autorizacije nad konkretnim zapisima, predvidiv reset token, SQL injection u sortiranju, pogrešna CORS provjera, Stored XSS, osjetljivi podaci u logovima, nesigurna YAML deserijalizacija i neodgovarajuće hashiranje lozinki. Za svaku ranjivost postoji zaseban sigurnosni test koji je prije popravka padao, a nakon popravka prolazio prema potvrdi polaznika. Snyk završno nije našao ranjive dependency putanje. Za potpunu predaju preostaje prikupiti dokaz SAST-a, završni ZAP report, točan JaCoCo postotak, završni Maven test sažetak i formalni SBOM.

## 10. Izjava

Izjavljujem da sam projekt izradio samostalno, da sam razumio i provjerio primijenjene popravke te da sam u ovom izvještaju naveo korištene izvore i pomoć. ChatGPT je korišten kao pomoć pri analizi, pripremi testnih scenarija i dokumentaciji; konačno izvršavanje naredbi, provjera rezultata i potvrda rada provedeni su u lokalnom okruženju polaznika.

**Polaznik:** ______________________________  **Datum:** __________________

## Literatura i poveznice

- OWASP Top 10:2025: https://owasp.org/Top10/2025/
- OWASP ASVS 5.0.0: https://github.com/OWASP/ASVS/tree/v5.0.0
- OWASP Cheat Sheet Series – Password Storage: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- Snyk CLI – test: https://docs.snyk.io/snyk-cli/commands/test
- Spring Boot reference documentation: https://docs.spring.io/spring-boot/
- SnakeYAML project: https://bitbucket.org/snakeyaml/snakeyaml/

---

**Dokumentacijska napomena:** ovaj izvještaj opisuje izmjene i testne rezultate koje je polaznik prijavio nakon rada na svojoj lokalnoj kopiji. Izvorni ZIP priložen u razgovoru sadrži početni projekt prije popravaka; prije konačne predaje u arhivu mora ući stvarna ažurirana mapa `java/` iz polaznikova računala.