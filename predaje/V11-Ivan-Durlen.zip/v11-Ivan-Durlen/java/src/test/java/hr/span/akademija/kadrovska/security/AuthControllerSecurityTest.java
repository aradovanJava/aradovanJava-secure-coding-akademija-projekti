package hr.span.akademija.kadrovska.security;

import hr.span.akademija.kadrovska.ApiTestBaza;
import org.junit.jupiter.api.*;
import org.springframework.http.HttpStatus;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.HexFormat;

import static org.assertj.core.api.Assertions.assertThat;

@Tag("Security")
class AuthControllerSecurityTest extends ApiTestBaza {

    @AfterEach
    public void resetPassword(){

    }

    @Test
    void tokenZaResetSeNeMozePogoditi() throws NoSuchAlgorithmException{
        /*
        TODO: reset lozinke utjeće na sve testove
        String loginToken = prijava("ana", "Ana12345!");

        Odgovor odgovorNaZahtjevZaReset = posalji("POST", "/api/auth/reset-zahtjev", loginToken, "application/json", "{\"username\": \"ana\"}");
        assertThat(odgovorNaZahtjevZaReset.status()).isEqualTo(HttpStatus.ACCEPTED.value());

        String token = md5("ana" + LocalDate.now());
        Odgovor odgovorNaReset = posalji("POST", "/api/auth/reset", null, "application/json", "{\"token\": \"" + token + "\",\"novaLozinka\": \"12345678\"}");
        System.out.println(odgovorNaReset);
        assertThat(odgovorNaReset.status()).isEqualTo(HttpStatus.BAD_REQUEST.value());
         */
    }


    @Test
    @Disabled("Until implemented")
    void tokenSeNeMozeIskoristitiVisePuta(){
        //TODO:
    }


    String md5(String s) throws NoSuchAlgorithmException{
        MessageDigest md = MessageDigest.getInstance("MD5");
        return HexFormat.of().formatHex(md.digest(s.getBytes(StandardCharsets.UTF_8)));
    }

}
