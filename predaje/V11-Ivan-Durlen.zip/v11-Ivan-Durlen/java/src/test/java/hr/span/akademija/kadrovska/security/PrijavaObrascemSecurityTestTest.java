package hr.span.akademija.kadrovska.security;

import hr.span.akademija.kadrovska.ApiTestBaza;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@Tag("Security")
public class PrijavaObrascemSecurityTestTest extends ApiTestBaza {

    @Test
    public void prijavaNeVodiNaBiloKojuStranicuVanDomene(){
        Odgovor odgovor = postForma("/prijava",
                Map.of("username", "ana", "password", "Ana12345!", "returnUrl", "http://www.google.com"));
        assertThat(odgovor.zaglavlja().map()).doesNotContainKey("set-cookie");
        assertThat(odgovor.status()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    }


    @Test
    public void prijavaNeVodiNaBiloKojuStranicuVanDomene2(){
        Odgovor odgovor = postForma("/prijava",
                Map.of("username", "ana", "password", "Ana12345!", "returnUrl", "ftp://www.google.com"));
        assertThat(odgovor.zaglavlja().map()).doesNotContainKey("set-cookie");
        assertThat(odgovor.status()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    }




}
