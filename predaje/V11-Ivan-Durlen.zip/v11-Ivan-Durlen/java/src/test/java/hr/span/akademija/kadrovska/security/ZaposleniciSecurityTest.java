package hr.span.akademija.kadrovska.security;

import hr.span.akademija.kadrovska.ApiTestBaza;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import static org.assertj.core.api.Assertions.assertThat;

@Tag("Security")
public class ZaposleniciSecurityTest extends ApiTestBaza {

    @Test
    public void umetnutiSqlUSortuVracaBadRequest() throws UnsupportedEncodingException {
        String token = prijava("ana", "Ana12345!");
        String umetnutiSql = "1; INSERT INTO zaposlenici (id, ime, prezime, odjel, email) VALUES (200, 'ivan', 'durlen', 'black-hat', 'ivan@mail.com');--";

        Odgovor odgovor = get("/api/zaposlenici?sort=" + URLEncoder.encode(umetnutiSql, "UTF-8") + "&smjer=asc", token);

        assertThat(odgovor.status()).isEqualTo(HttpStatus.BAD_REQUEST.value());
    }


    @Test
    public void umetnutiSqlUSmjeruVracaBadRequest() throws UnsupportedEncodingException {
        String token = prijava("ana", "Ana12345!");
        String umetnutiSql = "ASC; INSERT INTO zaposlenici (id, ime, prezime, odjel, email) VALUES (200, 'ivan', 'durlen', 'black-hat', 'ivan@mail.com');--";

        Odgovor odgovor = get("/api/zaposlenici?sort=ime&smjer=" + URLEncoder.encode(umetnutiSql, "UTF-8"), token);

        assertThat(odgovor.status()).isEqualTo(HttpStatus.BAD_REQUEST.value());

    }

}
