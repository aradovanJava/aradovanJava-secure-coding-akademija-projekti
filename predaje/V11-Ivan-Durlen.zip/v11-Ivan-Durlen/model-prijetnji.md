# Model prijetnji (STRIDE) – Kadrovska – HR portal, varijanta V11

Model prijetnji radi se **prije** traženja ranjivosti: pomaže sustavno odrediti gdje tražiti. Na kraju projekta
ga dopuni stvarnim nalazima (stupac „Nalaz”).

## 1. Opis sustava

**Akteri:**
 - anonimni posjetitelj 
 - prijavljeni korisnik:
   - KORISNIK
   - VODITELJ 
   - ADMIN

**Komponente:**
- REST API
- HTTP preglednik
- HTML stranice
- datotečni sustav
- baza podataka
- XML dokumenti
- YAML dokumenti
- "E-pošta" (simulacija putem datoteka)

**Tokovi podataka i granice povjerenja:** 

```
Korisnik/Preglednik -> granica povjerenja -> API -> datotečni sustav
                                                 -> baza podataka
                                                 -> SMTP (e-mail) server (simulacija datotekama) 
```


## 2. Imovina

| Imovina | Zašto je vrijedna | Tko joj smije pristupiti |
|---|---|---|
| *npr. lozinke korisnika* | omogućava autentikaciju korisnika | nitko, mora biti jednosmjerno hashirana |
| *auth/login token* | omogućava pristup resursima/dijelovima aplikacije | korisnik koji je vlasnik tokena |
| *reset token* | omogućava ponovno postavljanje lozinke | korisnik koji ponovno postavlja lozinku (dobiva ju "e-mailom") |
| *osobni podaci - ime, prezime, oib)* | osjetljivi podaci, zaštićeni GDPR-om| korisnik koji je vlasnik podataka, njegov nadređeni, administrator sustava |
| *platne liste korisnika* | osjetljivi podaci, zaštićeni GDPR-om| korisnik koji je vlasnik platne liste, njegov nadređeni, (administrator sustava?)|
| *popis edukacija*| određuje moguće edukacije za zaposlenike| čitanje - svi korisnici, kreiranje/mijenanje - voditelj i administrator sustava|
| *postavke sustava*| određuje postavke sustava koje se primienjuju svima| mijenanje - administrator sustava|

## 3. Prijetnje po STRIDE kategorijama

| Element (endpoint / komponenta) | S – lažno predstavljanje | T – neovlaštena izmjena | R – poricanje | I – otkrivanje informacija | D – uskraćivanje usluge | E – podizanje ovlasti |
|---|---|---|---|---|---|---|
| `POST /api/auth/login` | | | | | | |
| `POST /prijava` | | | | | | |
| | | | | | | |

*Upiši konkretnu prijetnju u polje ili „–” ako nije primjenjivo. Prođi kroz sve endpointe iz `http/kadrovska.http` i README-a.*

## 4. Procjena rizika i mjere

| # | Prijetnja | Vjerojatnost (1–3) | Utjecaj (1–3) | Rizik (V×U) | Postojeća zaštita | Potrebna mjera | Nalaz |
|---|---|---|---|---|---|---|---|
| P-01 | | | | | | | N-0? |
| | | | | | | | |

## 5. Zaključak

*Koje prijetnje su se pokazale stvarnim ranjivostima, koje su bile dobro zaštićene i što bi model trebao
uključivati u budućim verzijama aplikacije.*
