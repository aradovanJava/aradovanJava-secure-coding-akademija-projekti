package hr.span.akademija.medtermin.platforma;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

/** Postavke aplikacije iz {@code application.properties} (prefiks {@code app}). */
@ConfigurationProperties(prefix = "app")
public record AppProperties(String naziv, String storageDir, String mailboxDir, Cors cors) {

    // TODO(sec): spotbugs EI_EXPOSE_REP [MALICIOUS_CODE; provjeriti nalaz]: hr.span.akademija.medtermin.platforma.AppProperties$Cors.allowedOrigins() may expose internal representation by returning AppProperties$Cors.allowedOrigins
    public record Cors(List<String> allowedOrigins) {
        // M07: Obrambena kopija sprečava naknadnu izmjenu konfigurirane CORS liste.
        public Cors { allowedOrigins = allowedOrigins == null ? null : List.copyOf(allowedOrigins); }
    }

    public List<String> dopusteniOrigini() {
        if (cors == null || cors.allowedOrigins() == null) {
            return List.of();
        }
        return cors.allowedOrigins().stream().map(String::trim).filter(o -> !o.isEmpty()).toList();
    }
}
