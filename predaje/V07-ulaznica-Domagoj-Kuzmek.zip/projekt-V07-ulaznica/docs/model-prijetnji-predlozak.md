# Model prijetnji (STRIDE) – Ulaznica – prodaja ulaznica, varijanta V07

Model prijetnji radi se **prije** traženja ranjivosti: pomaže sustavno odrediti gdje tražiti. Na kraju projekta
ga dopuni stvarnim nalazima (stupac „Nalaz”).

## 1. Opis sustava

**Akteri:** anonimni posjetitelj, prijavljeni kupac (KORISNIK), ORGANIZATOR, ADMIN i napadač koji pokušava
pristupiti tuđim podacima ili lozinkama.

**Komponente:** web preglednik ili HTTP klijent, ASP.NET Core REST API i HTML stranice, SQLite baza,
datoteke računa i pošte, log aplikacije te simulirani servis naplate.

**Tokovi podataka i granice povjerenja:** *Nacrtaj jednostavan dijagram (DFD) – rukom, u draw.io ili kao tekst.
Označi gdje podaci prelaze granicu povjerenja (internet → API, API → baza, API → datotečni sustav, …).*

```
[Korisnik/preglednik] --HTTP--> | granica povjerenja | --> [API] --> [Baza]
                                                         |--> [Datoteke]
                                                         |--> [Log]
```
Korisnik unosi podatke kroz preglednik i prelazi granicu HTTP-a. API zatim čita i piše podatke u bazu,
datotečni sustav i log. Pristup financijskim i osobnim podacima mora se provjeriti na samom poslužitelju.

## 2. Imovina

| Imovina | Zašto je vrijedna | Tko joj smije pristupiti |
|---|---|---|
| Lozinke i reset tokeni | Omogućuju prijavu i preuzimanje računa. | Vlasnik lozinke i administrativni sustav koji ih sigurno obrađuje. |
| Sesijski tokeni i kolačić | Vezani su za identitet i ovlasti korisnika. | Prijavljeni korisnik i poslužitelj; ne drugi klijenti. |
| OIB i osobni podaci | Osobni su podaci i osjetljivi za privatnost. | Kupac, ovlašteni administrator i sustav koji izdaje račun. |
| Narudžbe, ulaznice i računi | Dokazuju kupnju i mogu imati novčanu vrijednost. | Kupac, vlastnik narudžbe i administrator. |
| Podaci o događajima i kapacitet | Na njima se temelji prodaja i broj slobodnih mjesta. | Javno čitanje; izmjena samo organizatora ili administratora. |
| Datoteke dokumenata i pošte | Sadrže račune i poveznice za obnovu lozinke. | Samo vlasnik računskog sadržaja i ovlaštene administrativne funkcije. |

## 3. Prijetnje po STRIDE kategorijama

| Element (endpoint / komponenta) | S – lažno predstavljanje | T – neovlaštena izmjena | R – poricanje | I – otkrivanje informacija | D – uskraćivanje usluge | E – podizanje ovlasti |
|---|---|---|---|---|---|---|
| `POST /api/auth/login` i `/prijava` | Napadač može pogoditi lozinku ili iskoristiti ukradene podatke. | Navedena lozinka ne smije mijenjati podatke tuđeg korisnika. | Neuspjeli pokušaji trebaju ostati u revizijskom zapisu. | Lozinka se ne smije spremiti u log. | Ponavljene provjere mogu trošiti resurse. | Kompromitiran administrator može dobiti administratorske ovlasti. |
| `POST /api/auth/register` | Napadač može stvarati lažne ili neželjene račune. | Uloga se mora dodijeliti samo kao `KORISNIK`, ne iz korisnikovog zahtjeva. | Registracija nije vezana uz stvarnu osobu bez daljnje provjere. | Ne smije se otkriti postoji li korisničko ime. | Moguće masovno stvaranje računa i BCrypt izračuni. | Klijent ne smije moći dodati ulogu administratora. |
| `POST /api/auth/reset-zahtjev` i `/reset` | Ukraden reset token može predstavljati vlasnika računa. | Token smije jednokratno promijeniti lozinku. | Potrebna je provjera uspjeha i vremena upotrebe. | Token i osobni podaci ne smiju biti u logovima. | Previše zahtjeva može stvarati tokene i opterećivati BCrypt. | Vlasnik valjanog tokena može preuzeti račun. |
| `/api/dogadjaji` i `/api/dogadjaji/uvoz` | Privilegirani račun može se zloupotrijebiti. | Uvoz mora provjeriti XML i samo organizator ili admin smije mijenjati događaje. | Uvoz i neuspjeli XML pokušaji treba evidentirati. | XML i odgovor ne smiju otkrivati lokalne datoteke. | Velik ili loše oblikovan XML može trošiti memoriju i bazu. | Obični korisnik ne smije biti organizator ni administrator. |
| `/api/narudzbe` i `/api/narudzbe/{id}` | Ukradena sesija može kupiti ili stornirati kao drugi korisnik. | Kupac narudžbe mora biti vezan uz sesiju; ID narudžbe mora provjeriti vlasništvo. | Kupnja i storniranje trebaju ostati u logu. | Ime na ulaznici, OIB i podaci narudžbe ne smiju se izlagati drugima. | Istodobne kupnje mogu premašiti kapacitet. | Neovlaštena sesija ne smije mijenjati tuđe narudžbe. |
| `/api/racuni` i `/ispis/narudzbe/{id}` | Ukraden token može otvoriti tuđe račune. | ID računa ili ulaznice mora provjeriti vlasništvo. | Ne treba spremiti detaljan privatni sadržaj računa u log. | Računi i ime na ulaznici smiju se prikazati samo vlasniku ili administratoru. | Čitanje velikih datoteka i PDF izrada mogu se ponavljati. | Administrator je ovlašten, obični korisnik ne smije izmijeniti druge podatke. |
| `/api/postavke` | Ukradena sesija može prikazati tuđe postavke. | ID korisnika mora se uzeti iz sesije, a ne iz klijenta. | Promjena postavki može ostati u audit logu. | YAML i poruke o pogrešci ne smiju otkriti podatke. | Neispravan ili velik YAML može trošiti resurse. | Klijent ne smije mijenjati ulogu ili drugog korisnika. |

## 4. Procjena rizika i mjere

| # | Prijetnja | Vjerojatnost (1–3) | Utjecaj (1–3) | Rizik (V×U) | Postojeća zaštita | Potrebna mjera | Nalaz |
|---|---|---|---|---|---|---|---|
| P-01 | XSS kroz ime na ulaznici u HTML ispisu | 3 | 3 | 9 | HTML kodiranje je sada dodano | Potvrditi kodiranje na svim novim HTML ispisima | N-01 |
| P-02 | XXE prilikom XML uvoza | 2 | 3 | 6 | DTD zabranjen, vanjski resolver je isključen | Zadržati test i ograničiti veličinu XML-a | N-02 |
| P-03 | Neovlašteno storniranje tuđe narudžbe | 3 | 3 | 9 | Provjera vlasništva i provjera uloge | Dodati testove i provjeriti sve rukovanja s ID-om | N-03 |
| P-04 | Otvaranje vanjske stranice kroz `returnUrl` | 2 | 2 | 4 | Prihvaća se samo lokalni URL | Zadržati test i provjeriti sve preusmjeravanja | N-04 |
| P-05 | Javno skladištenje lozinke kao običnog sažetka | 2 | 3 | 6 | Lozinka se čuva BCrypt hashom | Provjeriti radnu faktoru i migraciju postojećih zapisa | N-05 |
| P-06 | Prolazak dviju kupnji preko kapaciteta | 2 | 3 | 6 | Iznos i kapacitet provjeravaju se prije upisa | Provjeriti i rezervirati atomarno u transakciji | N-07 |
| P-07 | Čitanje tuđe datoteke preko naziva putanje | 2 | 3 | 6 | Provjera postojanja i djelomična provjera vlasnika | Uspostaviti dopušteni direktorij i čitati samo zapis iz baze | N-08 |
| P-08 | Lozinka ili OIB završava u logu | 3 | 3 | 9 | Djelomično se bilježi korisničko ime i naziv datoteke | Ne logirati tijelo zahtjeva niti osobne podatke | N-06 |
| P-09 | Nedostatak HSTS zaštite preglednika | 2 | 2 | 4 | CSP i ograničenje CORS-a postoje | Dodati HSTS uz TLS konfiguraciju | N-09 |

## 5. Zaključak
Najveći rizik je nastao kada aplikacija nije provjerila tko smije pristupiti podacima ili kada je korisnički
unos završio u drugom formatu bez kodiranja. Potpuno provjerene kontrole su SQL parametri, XML zabranjeni DTD,
BCrypt lozinke, provjera lokalnog preusmjeravanja i ograničenje uvoznih uloga.

Još treba poboljšati atomarnu kupnju, izolaciju datotečnog puta, zaštitu logova i HSTS konfiguraciju.
Za sljedeću verziju model treba uključiti rate limiting, rok i opoziv sesija, CSRF zaštitu, TLS infrastrukturu
i kontrolu pristupa logovima.
