# Izvještaj o sigurnosnoj analizi i popravcima

**Secure Coding akademija · Tjedan 2 · projekt V07 – Ulaznica – prodaja ulaznica**

| | |
|---|---|
| Polaznik | Domagoj Kuzmek |
| Varijanta | V07 |
| Tehnologija C# .NET
| Datum | 18. 11. 2026. |
| Korišteni savjeti s Moodlea | Moodle upute za razinu 1 i razinu 2 |
| Korišteni AI asistenti | Da – pomoć pri analizi dokumentacije, kodu i popunjavanju izvještaja |

## 1. Sažetak

Analiziran je lokalni .NET projekt Ulaznica. Pregledom koda, sigurnosnih testova i dostupnih alata pronađene su
sljedeće glavne sigurnosne slabe točke: XSS u HTML ispisu, XXE u XML uvozu, neovlašteno storniranje tuđe
narudžbe, vanjsko preusmjeravanje i nesigurno skladištenje lozinke. Ti su popravci potvrđeni sigurnosnim testovima,
a cjelokupni skup ima 40 testova koji sve prolaze. Još ostaju poboljšanja pokrivanja atomarnosti kupnje,
izolacije putanja datoteke, logova i HSTS-a. Coverlet pokrivenost linija je 90,5 %.

| Pronađeno | Ispravljeno | Sigurnosnih testova (crveno → zeleno) | Pokrivenost koda |
|---|---|---|---|
| 9 namjerno provjeravanih kontrolnih područja | barem 5 potvrđenih sigurnosnih popravaka | 40 ukupnih testova, svi prolaze | 90,5 % linija |

## 2. Metodologija i alati

| Alat | Vrsta (SAST/SCA/DAST/ručno) | Verzija | Naredba / postavke | Izvještaj prije | Izvještaj poslije |
|---|---|---|---|---|---|
| Semgrep | SAST | Postavljena verzija alata u okruženju | `semgrep scan --config p/owasp-top-ten --config p/security-audit dotnet/ --sarif` | `alati/prije/semgrep-dotnet.sarif` | `alati/poslije/semgrep-dotnet.sarif` |
| OSV-Scanner | SCA | CLI verzija iz okruženja | `osv-scanner scan source -r dotnet/` | `alati/prije/osv-scanner-report.md` | `alati/poslije/osv-scanner-report-poslije.md` |
| OWASP ZAP | DAST | Lokalna verzija ZAP-a | Automatski i pasivni pregled lokalnog servera na portu 5080 | `alati/prije/ZAP-report/` | `alati/poslije/ZAP-Report-after-.html` |
| Coverlet / ReportGenerator | Pokrivenost | Verzija iz testnog okruženja | `dotnet test --collect:"XPlat Code Coverage"` i ReportGenerator | – | `alati/poslije/pokrivenost/index.html` |
| Ručni pregled koda | Ručno | — | Pregled kontrolera, autorizacije, baze, XML-a, logova i datoteka | – | Izmijenjeni izvorni kod i sigurnosni testovi |

## 3. Model prijetnji (sažetak)

Najvažnija imovina je lozinka, sesijski token, OIB, narudžba i račun. Granice povjerenja prelaze se između
preglednika i API-ja, zatim između API-ja i SQLite baze, datoteka te logova. Pet najvećih rizika bila su:
neovlašten pristup tuđim podacima, XSS u HTML-u, XXE u uvozu XML-a, otkrivanje tajni kroz logove i gubitak
integriteta zbog istodobnih kupnji. Cjeloviti model nalazi se u [`prijetnje-po-stride.md`](prijetnje-po-stride.md).

## 4. Nalazi
Za svaku ranjivost naveden je dokaz i način provjere. Ranjivosti koje više nisu prisutne označene su kao
popravljene; preostali nedostaci označeni su kao otvoreni.

### N-01: Cross-Site Scripting u HTML ispisi ulaznice

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A05 – Injection / CWE-79 |
| Lokacija | `GET /ispis/narudzbe/{id}`, [`IspisController.cs`](../dotnet/src/Ulaznica.Api/Prodaja/IspisController.cs) |
| Kako je pronađeno | Ručni pregled i `IspisUlazniceTest` |
| Ozbiljnost | Visoka – korisnički tekst se izravno može pokazati kao HTML i uložiti skriptni kod. |
| Dokaz | U ime na ulaznici poslan je `<script>alert('XSS')</script>`. Nakon popravka odgovor ne sadrži izvorni skript, nego HTML kodirani tekst. |
| Uzrok | Vrijednost iz baze bila je umetnuta u HTML ispis bez zaštite. |
| Popravak | Dodano je `HtmlEncoder.Default.Encode()` za naziv, ime, mjesto, datum i ostale podatke. |
| Test | `IspisUlazniceNeIzvrsavaZlonamjerniHtml` – padao na ranjivom kodu, prolazi poslije. |
| Potvrda | Test provjerava da izvorni `<script>` ne ostaje u odgovoru. |
| Preporuka | Na svakom izlazu u HTMLu koristiti encoding prema kontekstu i automatske sigurnosne testove. |

### N-02: XML external entity (XXE)

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A05 – Injection / CWE-611 |
| Lokacija | `POST /api/dogadjaji/uvoz`, [`DogadjajiController.cs`](../dotnet/src/Ulaznica.Api/Prodaja/DogadjajiController.cs) |
| Kako je pronađeno | Ručni pregled i sigurnosni test |
| Ozbiljnost | Visoka – XML parser bi mogao čitati lokalne datoteke ili druge vanjske izvore. |
| Dokaz | XML je sadržavao DTD i `SYSTEM` entitet koji pokazuje na privremenu datoteku. Očekivani odgovor je 400 bez sadržaja datoteke. |
| Uzrok | XML se morao parsirati restriktivno i bez omogućavanja resolvera. |
| Popravak | `DtdProcessing.Prohibit` i `XmlResolver = null` u `XmlReaderSettings`. |
| Test | `UvozOdbijaDtdKojiReferenciraLokalnuDatoteku` – prolazi poslije popravka. |
| Potvrda | Nije dopušteno razrješavanje DTD-a ni čitanje lokalnog entiteta. |
| Preporuka | Ostaviti zabranu DTD-a i kontinuirano testirati XML uvoz zlonamjernim primjerima. |

### N-03: Neovlašteno storniranje tuđe narudžbe

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A01 – Broken Access Control / CWE-639 |
| Lokacija | `DELETE /api/narudzbe/{id}`, [`NarudzbeController.cs`](../dotnet/src/Ulaznica.Api/Prodaja/NarudzbeController.cs) |
| Kako je pronađeno | Ručni pregled i sigurnosni test |
| Ozbiljnost | Visoka – prijavljeni korisnik može promijeniti podatak drugog korisnika. |
| Dokaz | Marko pokušava stornirati narudžbu ID 1 koja pripada Ani i mora dobiti `404` ili `403`. Test očekuje `404`. |
| Uzrok | Ranije storniranje nije provjerilo vlasništvo narudžbe. |
| Popravak | Storno sada uspoređuje `korisnik.Username` s kupcem iz zapisa narudžbe. |
| Test | `KorisnikNeMozeStorniratiTuduNarudzbu` – prolazi nakon popravka. |
| Potvrda | Tuđa narudžba se ne briše i ne vraća detalj koji otkriva njen broj. |
| Preporuka | Pri svakoj operaciji nad objektom provjeriti vlasništvo na poslužitelju. |

### N-04: Otvoreno preusmjeravanje

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A01 – CWE-601 |
| Lokacija | `POST /prijava`, [`StraniceController.cs`](../dotnet/src/Ulaznica.Api/Autentikacija/StraniceController.cs) |
| Dokaz | `returnUrl=https://opasna-stranica.hr` mora završiti preusmjeravanjem na `/`, bez apsolutnog URL-a. |
| Popravak | Nakon prijave koristi se samo `Url.IsLocalUrl(returnUrl)`. |
| Test | `PrijavaSaVanjskiReturnUrlPreusmjeravaNaPocetnuStranicu` – prolazi. |
| Potvrda | Vanjski URL nije vraćen u zaglavlju `Location`. |

### N-05: Nesigurno spremanje lozinke

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A04 – CWE-916 |
| Lokacija | [`LozinkeServis.cs`](../dotnet/src/Ulaznica.Api/Autentikacija/LozinkeServis.cs) |
| Ozbiljnost | Visoka – ista lozinka ne smije imati istu hash vrijednost. |
| Popravak | Lozinke se čuvaju BCrypt hashom s jedinstvenim slučajnim saltom. |
| Test | `IstaLozinkaMoraImatiRazliciteHashVrijednosti` – prolazi. |
| Preporuka | Ne mijenjati BCrypt za jednostavne hash funkcije i redovito provjeravati radnu faktoru. |

### N-06: Osjetljivi podaci u logovima

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A09 – Security Logging and Alerting / CWE-532 |
| Lokacija | `POST /api/auth/login`, `POST /api/narudzbe` i pripadajući `ILogger` pozivi |
| Ozbiljnost | Srednja do visoka – lozinke ili OIB mogu biti vidljivi osobama koje nemaju pravo pristupa logovima. |
| Uzrok | `logger.LogInformation("Zahtjev za prijavu: {Zahtjev}", zahtjev)` i logiranje cijelog objekta narudžbe zapisuje osobne podatke. |
| Stanje | Otvoren nedostatak; zahtijeva uklanjanje lozinke i OIB-a iz poruka loga. |
| Preporuka | Logirati samo korisničko ime ili ID, rezultat i vrijeme; maskirati osobne podatke. |

### N-07: Istodobne kupnje mogu prijeći kapacitet

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A10 – CWE-367 |
| Lokacija | [`NarudzbeController.cs`](../dotnet/src/Ulaznica.Api/Prodaja/NarudzbeController.cs), metoda `Stvori` |
| Ozbiljnost | Visoka – više istodobnih kupnji može rezervirati više mjesta nego što ih događaj ima. |
| Uzrok | Provjera `prodano + kolicina > kapacitet` i `UPDATE` nisu jedna atomska transakcija. |
| Stanje | Otvoren nedostatak; treba dodati zaključavanje ili atomarni SQL uvjet. |
| Preporuka | Izvršiti provjeru i povećanje u transakciji, uz uvjet da prodano plus količina ne prelazi kapacitet. |

### N-08: Nedostatna stroga provjera putanje datoteke

| Polje | Opis |
|---|---|
| Kategorija | OWASP Top 10:2025 A01 – CWE-22 |
| Lokacija | `GET /api/racuni/preuzmi`, [`RacuniController.cs`](../dotnet/src/Ulaznica.Api/Prodaja/RacuniController.cs) |
| Ozbiljnost | Visoka – unos naziva datoteke mora biti strogo vezan uz račun i dopušteni direktorij. |
| Uzrok | Provjera se oslanja na korisničko ime u nazivu datoteke, a putanja nije provjerena kao strogo normalizirana. |
| Stanje | Otvoren nedostatak. |
| Preporuka | Pronaći naziv u bazi po ID-u i kupcu, pretvoriti putanju u punu putanju te provjeriti da počinje dopuštenim direktorijem. |

### N-09: Nedostaje HSTS

| Polje | Opis |
|---|---|
| Kategorija | OWASP ASVS 3.4.1 / CWE-319 |
| Lokacija | [`Program.cs`](../dotnet/src/Ulaznica.Api/Program.cs) |
| Ozbiljnost | Srednja – bez HSTS-a preglednik može otvoriti nesigurnu HTTP inačicu gdje je to dopušteno mrežom. |
| Stanje | Otvoren nedostatak u kodu. |
| Preporuka | Aktivirati HTTPS i HSTS u produkcijskoj konfiguraciji, uz omjereno polje `Max-Age`. |

## 5. Lažno pozitivni i odbačeni nalazi alata
| Alat | Nalaz | Zašto nije stvarna ranjivost u ovoj aplikaciji |
|---|---|---|
| Semgrep / Roslyn | Općenita upozorenja o SQL-u ili zlonamjernom unosu | Kod koristi `SqliteParameter` kroz `Baza.Naredba`, pa vrijednosti nisu umetnute u SQL tekst kao string. |
| SAST | Otvorena putanja ili unos u XML-u | XML uvoz je ograničen, DTD zabranjen i vanjski resolver postavljen na `null`. |
| ZAP | Nedostajuća CSP/HSTS zaglavlja | CSP se vraća globalnim middlewareom. HSTS još nije konfiguriran i ostaje u modelu rizika. |
| OSV-Scanner | Ranjiva stara verzija YamlDotNet / SQLitePCLRaw | Izvještaj prije prikazuje stare verzije; `.csproj` poslije koristi YamlDotNet 18.1.0 i Microsoft.Data.Sqlite 10.0.0. |

## 6. Usklađenost s OWASP ASVS 5.0.0

*Sažetak iz `asvs-kontrolna-lista.md`: broj zahtjeva koje aplikacija ispunjava prije i poslije popravaka;
zahtjevi koji ni nakon popravaka nisu ispunjeni i zašto.*

| | Ispunjeno | Djelomično | Nije ispunjeno | Nije primjenjivo |
|---|---|---|---|---|
| Prije popravaka | 3 | 0 | 23 | 0 |
| Poslije popravaka | 19 | 0 | 7 | 0 |

Nakon popravaka nisu u potpunosti ispunjeni zahtjevi koji se odnose na atomarnu prodaju i zaključavanje
resursa, strogu izolaciju putanja datoteka, logiranje bez osjetljivih podataka, HSTS te sigurno ponašanje
kod pojedinih pogrešaka. Ostale otvorene kontrolne točke nisu potvrđene kao ranjivosti, nego kao dodatna
pojačanja koja tek treba implementirati.

## 7. Testovi i pokrivenost koda

| Test | Ranjivost | Izvorni kod | Nakon popravka |
|---|---|---|---|
| `IspisUlazniceNeIzvrsavaZlonamjerniHtml` | N-01 | Padao bi bez HTML encodinga | Prolazi |
| `UvozOdbijaDtdKojiReferenciraLokalnuDatoteku` | N-02 | Padao bi ako se razriješi DTD | Prolazi |
| `KorisnikNeMozeStorniratiTuduNarudzbu` | N-03 | Ranije dopuštao storniranje tuđe narudžbe | Prolazi |
| `PrijavaSaVanjskiReturnUrlPreusmjeravaNaPocetnuStranicu` | N-04 | Ranije mogao preusmjeriti van | Prolazi |
| `IstaLozinkaMoraImatiRazliciteHashVrijednosti` | N-05 | Jednostavni sažetak daje isti hash | Prolazi |
| `PrimjerSigurnosnogTesta.ZasticeniEndpointBezTokenaVraca401` | Autorizacija | Bez sesije je endpoint blokiran | Prolazi |

Ukupno je pokrenuto 40 testova: svih 40 je prošlo, 0 nije prošlo i 0 je preskočeno.

Pokrivenost koda (linije): **90,5 %** – alat: **Coverlet + ReportGenerator**.
Izvještaj pokrivenosti nalazi se u [`alati/poslije/pokrivenost/index.html`](../alati/poslije/pokrivenost/index.html).

## 8. Zaključak
Najteže je bilo razlikovati stvarne ranjivosti od lažno pozitivnih nalaza alata i provjeriti prilagodbu nad
ciljanom verzijom projekta. Najvažniji popravci bili su kodiranje HTML-a, zabrana DTD-a, provjera vlasništva,
ograničenje preusmjeravanja i BCrypt.

U stvarnom projektu poboljšao bih pokretanje SAST/SCA/DAST alata u CI-u, dodao automatizirane sigurnosne
testove za svaki popravak, učinio logove zaštitnim i dodao rate limiting, HTTPS/HSTS i reviziju prava pristupa.
Za narudžbe i kupnju koristio bih transakcije i zaključavanje baze kako se isto mjesto ne bi prodalo dvaput.

## 9. Izjava

Izjavljujem da sam projekt izradio samostalno i da sve korištene izvore i pomoć navodim u ovom izvještaju.

Ime Prezime, 18. 11. 2026.
