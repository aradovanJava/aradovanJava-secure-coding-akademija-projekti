Total 3 packages affected by 3 known vulnerabilities (1 Critical, 2 High, 0 Medium, 0 Low, 0 Unknown) from 1 ecosystem.
2 vulnerabilities can be fixed.

╭─────────────────────────────────────┬──────┬───────────┬────────────────────────────┬─────────┬───────────────┬─────────────────────╮
│ OSV URL                             │ CVSS │ ECOSYSTEM │ PACKAGE                    │ VERSION │ FIXED VERSION │ SOURCE              │
├─────────────────────────────────────┼──────┼───────────┼────────────────────────────┼─────────┼───────────────┼─────────────────────┤
│ https://osv.dev/GHSA-rpch-cqj9-h65r │ 7.8  │ NuGet     │ YamlDotNet                 │ 4.3.2   │ 5.0.0         │ Ulaznica.Api.csproj │
│ https://osv.dev/GHSA-2m69-gcr7-jv3q │ 9.8  │ NuGet     │ SQLitePCLRaw.lib.e_sqlite3 │ 2.1.11  │ --            │ packages.lock.json  │
│ https://osv.dev/GHSA-rpch-cqj9-h65r │ 7.8  │ NuGet     │ YamlDotNet                 │ 4.3.2   │ 5.0.0         │ packages.lock.json  │
╰─────────────────────────────────────┴──────┴───────────┴────────────────────────────┴─────────┴───────────────┴─────────────────────╯
