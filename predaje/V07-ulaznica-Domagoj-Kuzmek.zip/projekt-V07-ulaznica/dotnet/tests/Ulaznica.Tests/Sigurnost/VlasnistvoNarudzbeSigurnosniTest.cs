using System.Net;
using Ulaznica.Tests.Infrastruktura;
using Xunit;

namespace Ulaznica.Tests.Sigurnost;

/// <summary>
/// Sigurnosni test: provjerava da korisnik ne može stornirati
/// narudžbu koja pripada drugom korisniku.
/// </summary>
[Trait("Category", "Sigurnost")]
public sealed class VlasnistvoNarudzbeSigurnosniTest(
    UlaznicaFactory factory) : IClassFixture<UlaznicaFactory>
{
    [Fact]
    public async Task KorisnikNeMozeStorniratiTuduNarudzbu()
    {
        // Arrange – prijavljeni korisnik koji nije vlasnik narudžbe
        var klijent = await factory.KlijentZaAsync("marko", "Marko12345!");

        // ID narudžbe koja pripada drugom korisniku
        long idNarudzbe = 1;

        // Act
        var odgovor = await klijent.PostAsync(
            $"/api/narudzbe/{idNarudzbe}/storniraj",
            null
        );

        // Assert – pristup mora biti odbijen
        Assert.Equal(HttpStatusCode.NotFound, odgovor.StatusCode);
    }
}
