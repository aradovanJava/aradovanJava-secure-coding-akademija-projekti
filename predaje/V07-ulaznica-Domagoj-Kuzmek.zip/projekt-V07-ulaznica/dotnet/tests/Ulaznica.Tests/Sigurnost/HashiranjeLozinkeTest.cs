using Microsoft.Extensions.DependencyInjection;
using Ulaznica.Api.Autentikacija;
using Ulaznica.Tests.Infrastruktura;
using Xunit;

namespace Ulaznica.Tests.Sigurnost;

/// <summary>
/// Sigurnosni test: provjerava generira li se različita hash
/// vrijednost za istu lozinku zbog korištenja jedinstvenog salta.
/// </summary>
[Trait("Category", "Sigurnost")]
public sealed class HashiranjeLozinkeTest(UlaznicaFactory factory)
    : IClassFixture<UlaznicaFactory>
{
    [Fact]
    public void IstaLozinkaMoraImatiRazliciteHashVrijednosti()
    {
        // Arrange – priprema iste lozinke
        var lozinka = "TestLozinka123!";
        var servis = factory.Services.GetRequiredService<LozinkeServis>();

        // Act – dva puta hashiramo istu lozinku
        var hash1 = servis.Hashiraj(lozinka);
        var hash2 = servis.Hashiraj(lozinka);

        // Assert – hash vrijednosti moraju biti različite
        Assert.NotEqual(hash1, hash2);
    }
}
