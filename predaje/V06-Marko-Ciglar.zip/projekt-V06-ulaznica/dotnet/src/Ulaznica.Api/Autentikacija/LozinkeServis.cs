using System.Security.Cryptography;
using System.Text;

namespace Ulaznica.Api.Autentikacija;

/// <summary>Izračun i provjera sažetka lozinke (stupac <c>korisnici.password_hash</c>).</summary>
public sealed class LozinkeServis
{
    public string Hashiraj(string lozinka) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(lozinka))).ToLowerInvariant();

    public bool Provjeri(string spremljeniHash, string lozinka) =>
        string.Equals(spremljeniHash, Hashiraj(lozinka), StringComparison.Ordinal);
}
