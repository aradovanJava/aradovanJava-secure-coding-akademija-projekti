import hashlib
import hmac


class LozinkaHasher:
    """Izračun i provjera sažetka lozinke (registracija, prijava, promjena lozinke, početni podaci)."""

    def hash(self, lozinka: str) -> str:
        return hashlib.sha256(lozinka.encode("utf-8")).hexdigest()

    def provjeri(self, lozinka: str, spremljeni_hash: str | None) -> bool:
        if spremljeni_hash is None:
            return False
        return hmac.compare_digest(self.hash(lozinka), spremljeni_hash)
