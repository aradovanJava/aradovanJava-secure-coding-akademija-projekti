"""Računi kupaca."""
