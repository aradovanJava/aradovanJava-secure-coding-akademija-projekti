"""Platne liste zaposlenika."""
