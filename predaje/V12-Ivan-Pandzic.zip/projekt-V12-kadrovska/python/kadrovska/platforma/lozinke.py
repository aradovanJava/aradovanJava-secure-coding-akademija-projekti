from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

_hasher = PasswordHasher()


class LozinkaHasher:
    """Izračun i provjera sažetka lozinke (registracija, prijava, promjena lozinke, početni podaci)."""

    def hash(self, lozinka: str) -> str:
        return _hasher.hash(lozinka)

    def provjeri(self, lozinka: str, spremljeni_hash: str | None) -> bool:
        if spremljeni_hash is None:
            return False
        try:
            return _hasher.verify(spremljeni_hash, lozinka)
        except VerifyMismatchError:
            return False
