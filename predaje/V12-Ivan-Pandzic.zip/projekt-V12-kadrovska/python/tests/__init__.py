"""Testovi aplikacije Kadrovska."""
