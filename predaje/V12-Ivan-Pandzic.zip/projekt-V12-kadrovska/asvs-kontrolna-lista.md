# Kontrolna lista – OWASP ASVS 5.0.0 (odabrani zahtjevi) – Kadrovska – HR portal, varijanta V12

OWASP *Application Security Verification Standard* (ASVS) 5.0.0 je standard zahtjeva za provjeru sigurnosti web
aplikacija (razine L1–L3). Za ovaj projekt odabran je podskup zahtjeva. Za svaki zahtjev provjeri stanje
aplikacije **prije** i **poslije** svojih popravaka i upiši:

- **Da** – zahtjev je ispunjen · **Djelomično** · **Ne** · **N/P** – nije primjenjivo (obrazloži)
- **Dokaz** – kako si to provjerio (test, alat, isječak koda, zahtjev/odgovor).

Opisi su skraćeni prijevodi – mjerodavan je izvorni tekst standarda (github.com/OWASP/ASVS, oznaka `v5.0.0`).

| ID | Razina | Zahtjev (skraćeno) | Prije | Poslije | Dokaz |
|---|---|---|---|---|---|
| 1.2.1 | L1 | Izlazno kodiranje (HTTP odgovor, HTML, XML) primjereno je kontekstu u koji se podatak umeće. | Ne | Da | Prije se `razlog` iz baze izravno umetao u HTML. Poslije `zahtjevi/ispis.py::_tekst()` koristi `html.escape`; `test_ispis_kodira_html_u_razlogu` prolazi. |
| 1.2.4 | L1 | Upiti prema bazi koriste parametrizirane upite, ORM ili su na drugi način zaštićeni od SQL injectiona. | Ne | Da | Prije su `sort` i `smjer` izravno umetani u `ORDER BY`. Poslije `zaposlenici.py` provjerava fiksne allowliste, a ostali upiti koriste `?` parametre; `test_sortiranje_odbija_sql_izraz` prolazi. |
| 1.5.1 | L1 | XML parseri su konfigurirani restriktivno; nesigurne mogućnosti poput razrješavanja vanjskih entiteta su isključene. | Ne | Da | Prije: `load_dtd=True`, `resolve_entities=True`. Poslije: `load_dtd=False`, `resolve_entities=False`, `no_network=True`; `test_uvoz_xml_ne_cita_vanjski_entitet` prolazi. |
| 1.5.2 | L2 | Deserijalizacija nepouzdanih podataka je sigurna (npr. dopušteni popis tipova objekata). | Da | Da | JSON se validira Pydantic modelima, a YAML se čita s `yaml.safe_load` i provjerom tipova u `postavke_api.py`; ne koristi se nesigurna objektna deserijalizacija. |
| 2.3.3 | L2 | Poslovna operacija uspije u cijelosti ili se vrati u prethodno ispravno stanje (transakcije). | Djelomično | Da | Prije prijava na edukaciju nije bila jedna transakcija. Poslije je cijela provjera, povećanje broja i spremanje prijave unutar `Baza.transakcija()`, koja radi COMMIT ili ROLLBACK. |
| 2.3.4 | L2 | Resursi ograničene količine zaštićeni su zaključavanjem na razini poslovne logike (npr. dvostruka rezervacija). | Ne | Da | Prije su dva zahtjeva mogla zauzeti zadnje mjesto. Poslije transakcija drži postojeći `RLock`; `test_samo_jedan_korisnik_dobiva_zadnje_mjesto` potvrđuje jedan 201, jedan 409 i stanje 20/20. |
| 3.4.1 | L1 | Odgovori sadrže zaglavlje `Strict-Transport-Security` (HSTS). | N/P | N/P | Aplikacija je namjerno dostupna samo lokalno na `http://127.0.0.1:8000`, bez TLS-a. U produkciji bi reverse proxy osigurao HTTPS, preusmjeravanje s HTTP-a i HSTS. |
| 3.4.2 | L1 | `Access-Control-Allow-Origin` je fiksna vrijednost ili se zaglavlje `Origin` provjerava prema popisu dopuštenih. | Da | Da | `CorsMiddleware` uspoređuje Origin s `APP_CORS_ALLOWED_ORIGINS` i vraća točno dopušteni origin; funkcionalni CORS testovi prolaze. |
| 3.4.3 | L2 | Odgovori sadrže zaglavlje `Content-Security-Policy`. | Ne | Ne | ZAP poslije popravaka prijavljuje „Content Security Policy Header Not Set” na HTML ispisu. XSS je uklonjen izlaznim kodiranjem, ali CSP nije dodan. |
| 3.7.2 | L2 | Aplikacija automatski preusmjerava samo na odredišta s popisa dopuštenih (ili upozorava korisnika). | Da | Da | `prijava.py::odrediste()` dopušta samo lokalne putanje koje počinju jednim `/`, bez `\\` i kontrolnih znakova; ostalo preusmjerava na `/`. |
| 5.3.2 | L1 | Pri radu s putanjama datoteka koriste se interno generirani podaci; korisnička imena datoteka se strogo provjeravaju. | Ne | Da | Prije je parametar `datoteka` izravno postajao putanja. Poslije `preuzmi()` najprije pronalazi točan zapis u tablici `platne_liste` i provjerava vlasnika; `test_preuzimanje_ne_dopusta_path_traversal` prolazi. |
| 6.2.1 | L1 | Lozinke koje postavlja korisnik imaju najmanje 8 znakova. | Da | Da | `korisnici.py::provjeri_lozinku()` zahtijeva najmanje osam znakova za registraciju i promjenu lozinke. |
| 6.4.3 | L2 | Postupak obnove zaboravljene lozinke je siguran. | Ne | Djelomično | Predvidljivi MD5 token zamijenjen je s `secrets.token_urlsafe(32)`; test potvrđuje različite tokene. Međutim, stupci `istjece` i `iskoristen` još se ne provjeravaju pa token ne istječe i nije jednokratan. |
| 8.2.1 | L1 | Pristup funkcijama ograničen je na korisnike s izričitim ovlastima. | Da | Da | Zaštićeni endpointi koriste `Prijavljeni`; XML uvoz dodatno zahtijeva ulogu VODITELJ ili ADMIN. Testovi autentikacije i funkcionalni testovi uloga prolaze. |
| 8.2.2 | L1 | Pristup konkretnim podacima (objektima) ograničen je na korisnike s izričitim ovlastima (IDOR/BOLA). | Ne | Da | Prije su preuzimanje datoteke i nepoznat format mogli otkriti tuđe podatke. Poslije se vlasništvo provjerava iz baze prije rada s datotekom i prije parsiranja formata; oba sigurnosna testa prolaze. |
| 8.3.1 | L1 | Pravila autorizacije provode se na pouzdanom sloju poslužitelja, ne na klijentu. | Da | Da | Autentikacija, provjera uloge i provjera vlasništva provode se u FastAPI dependencyjima, endpointima i servisima; klijentske vrijednosti ne određuju ulogu. |
| 11.4.1 | L1 | Koriste se samo odobrene hash funkcije (ne MD5) za kriptografske namjene. | Ne | Da | MD5 za reset token uklonjen je i zamijenjen kriptografski sigurnim `secrets.token_urlsafe(32)`; Ruff više ne prijavljuje S324. |
| 11.4.2 | L2 | Lozinke se pohranjuju odobrenom, računski zahtjevnom funkcijom za derivaciju ključa (npr. bcrypt, PBKDF2, Argon2). | Ne | Da | SHA-256 bez soli zamijenjen je Argon2id implementacijom `argon2.PasswordHasher`; `test_argon2_koristi_nasumicnu_sol` prolazi. |
| 15.1.2 | L2 | Postoji popis (npr. SBOM) svih komponenti trećih strana. | Da | Da | CycloneDX popis komponenti spremljen je kao `alati/prije/sbom.cdx.json`; verzije izravnih ovisnosti zaključane su u `requirements.txt` i `requirements-dev.txt`. |
| 15.2.1 | L1 | Aplikacija sadrži samo komponente koje nisu prekoračile rok za ažuriranje (bez poznatih ranjivosti). | Ne | Djelomično | Početni OSV izvještaj prijavio je ranjive tranzitivne verzije. Poslije su `anyio`, `h11`, `idna`, `certifi` i `pip` zaključani na popravljene verzije; OSV još statički prijavljuje `pip 9.0.3`, dok stvarno okruženje koristi `pip 26.3`, a pip-audit i Trivy ne nalaze ranjivosti. |
| 16.2.5 | L2 | Osjetljivi podaci se logiraju samo u skladu s razinom zaštite (npr. bez lozinki, maskirani osobni podaci). | Ne | Da | Prije su se logirali lozinka, OIB i razlog. Poslije se logiraju samo korisničko ime i vrsta događaja; `test_lozinka_oib_i_razlog_nisu_u_logu` prolazi. |
| 16.3.1 | L2 | Sve operacije autentikacije se logiraju, uključujući uspješne i neuspješne pokušaje. | Djelomično | Djelomično | Svaki API i web pokušaj prijave s korisničkim imenom prolazi kroz `KorisnikService.prijava()` i bilježi se bez lozinke, ali log ne razlikuje uspjeh od neuspjeha i ne bilježi sve događaje obnove/odjave. |
| 16.5.1 | L2 | Kod neočekivane ili sigurnosno osjetljive greške vraća se generička poruka (bez stack tracea i internih detalja). | Djelomično | Djelomično | Globalni handler vraća generički 500 bez stack tracea, validacijske i HTTP greške su ujednačene. Ipak, fallback za nepoznat format još vraća `repr(KeyError)` u polju `napomena`. |
| 16.5.3 | L2 | Aplikacija pri iznimci zakazuje sigurno – ne dolazi do „fail-open” ponašanja. | Ne | Da | Prije je `KeyError` nepoznatog formata preskakao autorizaciju. Poslije se vlasništvo provjerava prije `try` bloka; `test_nepoznat_format_ne_preskace_provjeru_vlasnika` prolazi. |
| 16.5.4 | L3 | Postoji zadnja linija obrane – rukovatelj koji hvata sve neuhvaćene iznimke. | Da | Da | `greske.py::registriraj()` registrira handler za `Exception`, zapisuje detalje u poslužiteljski log i klijentu vraća generički status 500. |

**Napomena uz 3.4.1:** aplikacija se lokalno pokreće bez TLS-a; obrazloži kako bi se zahtjev ispunio u produkciji.

## Sažetak

| | Da | Djelomično | Ne | N/P |
|---|---|---|---|---|
| Prije popravaka | 8 | 3 | 13 | 1 |
| Poslije popravaka | 19 | 4 | 1 | 1 |
