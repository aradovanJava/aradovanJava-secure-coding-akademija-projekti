# Model prijetnji (STRIDE) – Kadrovska – HR portal, varijanta V12

Model prijetnji radi se **prije** traženja ranjivosti: pomaže sustavno odrediti gdje tražiti. Na kraju projekta
ga dopuni stvarnim nalazima (stupac „Nalaz”).

## 1. Opis sustava

**Akteri:** 
- anonimni posjetitelj - mora se registrirati i prijaviti da bi koristio portal
- prijavljeni korisnik (KORISNIK) - može koristiti aplikaciju, pregledavati i uređivati svoje podatke, podnositi zahtjeve za godišnji odmor i edukacije
- VODITELJ - ima pristup funkcionalnostima za upravljanje edukacijama i pregled zahtjeva svojih zaposlenika
- ADMIN - ima pristup svim funkcionalnostima i podacima, uključujući administraciju korisnika i sustava


**Komponente:** 
- preglednik / HTTP klijent - Postman, Bruno, web preglednik
- REST API - FastAPI REST API koji obrađuje zahtjeve i vraća odgovore
- HTML stranice (prijava, ispis) - HTML stranice koje se prikazuju korisnicima, uključujući prijavu i ispis potvrda
- baza podataka - SQLite baza podataka
- datotečni sustav (dokumenti) - za pohranu platnih lista i drugih dokumenata
- „poštanski sandučić” (datoteke)
- log
- vanjski servis 

**Tokovi podataka i granice povjerenja:** *Nacrtaj jednostavan dijagram (DFD) – rukom, u draw.io ili kao tekst.
Označi gdje podaci prelaze granicu povjerenja (internet → API, API → baza, API → datotečni sustav, …).*

```
[Anonimni korisnik / zaposlenik / voditelj / admin]
                         |
                         | HTTP zahtjev, token ili SESSION kolačić
                         v
               | granica povjerenja |
                         |
                     [FastAPI]
                    /    |    \
                   v     v     v
             [SQLite] [Datoteke] [Log]
                          |
                  [dokumenti / pošta]

                     [FastAPI]
                         |
                         v
                       [LMS]
```

## 2. Imovina

| Imovina | Zašto je vrijedna | Tko joj smije pristupiti |
|---|---|---|
| lozinke korisnika | Bazični alat za zaštitu |Samo korisnik, tj. nitko u sustavu |
|osobni podaci (OIB, …) | Osjetljivi privatni podaci|Korisnik i administratori |
| dokumenti korisnika | Osjetljivi privatni podaci|Korisnik i administratori |
|Platne liste | Osjetljivi privatni podaci|Korisnik i administratori |
|Logovi | Služe dokazivanju događaja i otkrivanju incidenata| Administratori|

## 3. Prijetnje po STRIDE kategorijama

| Element (endpoint / komponenta) | S – lažno predstavljanje | T – neovlaštena izmjena | R – poricanje | I – otkrivanje informacija | D – uskraćivanje usluge | E – podizanje ovlasti |
|---|---|---|---|---|---|---|
| `GET /api/platne-liste/preuzmi` | – | Manipulacija parametrom `datoteka` i putanjom | – | Path traversal može otkriti datoteke izvan dopuštene mape | Čitanje velikih datoteka može opteretiti aplikaciju | Čitanje reset tokena može omogućiti preuzimanje privilegiranog računa |
| `POST /api/edukacije/uvoz` | – | Zlonamjerni XML može unijeti neželjen sadržaj | – | XXE može otkriti lokalne datoteke poslužitelja | XML entiteti mogu iscrpiti resurse | – |
| Pohrana lozinki u tablici `korisnici` | Ukradeni i brzo probijeni hash omogućuje predstavljanje korisnika | – | – | Krađa baze otkriva jednake i slabo zaštićene hash vrijednosti | – | Probijena lozinka VODITELJA ili ADMIN-a daje više ovlasti |
| `GET /api/zaposlenici?sort=…&smjer=…` | – | SQL izraz iz parametra može promijeniti ponašanje upita | – | SQL injection može otkriti podatke iz baze | Složeni SQL izraz može opteretiti bazu | SQL injection može zaobići namijenjena ograničenja upita |
| `GET /ispis/zahtjevi/{id}` | – | Zlonamjeran razlog mijenja sadržaj HTML stranice | – | Stored XSS može otkriti podatke ili token korisnika koji otvori ispis | Zlonamjerna skripta može ometati rad stranice | XSS u sesiji administratora može izvršavati radnje njegovim ovlastima |
| `POST /api/edukacije/{id}/prijava` | – | Istodobni zahtjevi mogu prekoračiti kapacitet edukacije | Korisnici mogu osporavati rezultat nekonzistentne prijave | – | Velik broj istodobnih prijava može iscrpiti kapacitet i resurse | – |
| Obnova lozinke (`reset-zahtjev`, `reset`) | Predvidljiv token omogućuje predstavljanje drugog korisnika | Napadač može promijeniti tuđu lozinku | Promjena se može poricati bez potpunog revizijskog zapisa | Reset token može procuriti iz datoteke ili URL-a | Masovni zahtjevi mogu stvarati mnogo poruka | Preuzimanje ADMIN računa omogućuje podizanje ovlasti |
| Log kod prijave i stvaranja zahtjeva | – | – | Osjetljive radnje teško je pouzdano dokazati ako log sadrži neprikladne podatke | Lozinka, OIB i razlog godišnjeg odmora mogu procuriti kroz log | Prekomjerno logiranje može popuniti prostor | Podaci iz loga mogu pomoći u preuzimanju računa |
| `GET /api/platne-liste/{id}?format=…` | – | Manipulacija parametrom `format` mijenja tok izvođenja | – | Nepoznat format preskače autorizaciju i otkriva tuđu platnu listu | – | Obični korisnik dobiva pristup objektu drugog korisnika |
*Upiši konkretnu prijetnju u polje ili „–” ako nije primjenjivo. Prođi kroz sve endpointe iz `http/kadrovska.http` i README-a.*

## 4. Procjena rizika i mjere

| # | Prijetnja | Vjerojatnost (1–3) | Utjecaj (1–3) | Rizik (V×U) | Postojeća zaštita | Potrebna mjera | Nalaz |
|---|---|---:|---:|---:|---|---|---|
| P-01 | Path traversal i pristup tuđim platnim listama preko parametra `datoteka` | 3 | 3 | 9 | Endpoint traži prijavu; postojala je slaba provjera korisničkog imena kao podniza naziva datoteke | Datoteku pronaći u bazi i provjeriti da prijavljeni korisnik odgovara vlasniku zapisa | N-02 |
| P-02 | XXE pri uvozu edukacija omogućuje čitanje lokalnih datoteka | 2 | 3 | 6 | Uvoz je ograničen na VODITELJ/ADMIN i parser ima `no_network=True` | Isključiti učitavanje DTD-a i razrješavanje vanjskih entiteta | N-06 |
| P-03 | Brzo pogađanje hashiranih lozinki zbog SHA-256 bez nasumične soli | 2 | 3 | 6 | Lozinke nisu spremljene kao čisti tekst, imaju najmanje osam znakova i uspoređuju se konstantnom usporedbom | Koristiti namjenski spori algoritam Argon2id s nasumičnom soli | N-03 |
| P-04 | SQL injection preko parametara `sort` i `smjer` | 2 | 3 | 6 | Endpoint zahtijeva prijavu; ostali upiti uglavnom koriste SQL parametre | Ograničiti stupac i smjer sortiranja fiksnim allowlistama | N-05 |
| P-05 | Stored XSS preko razloga zahtjeva na HTML stranici za ispis | 2 | 2 | 4 | Pristup ispisu ima provjeru vlasništva, a duljina razloga ograničena je na 500 znakova | Sve dinamičke tekstualne vrijednosti kodirati funkcijom `html.escape()` prije umetanja u HTML | N-07 |
| P-06 | Istodobne prijave mogu prekoračiti kapacitet edukacije | 2 | 2 | 4 | Provjeravaju se postojanje edukacije, prethodna prijava i kapacitet; pojedinačne DB operacije koriste bravu | Cijelu provjeru i spremanje izvršiti unutar jedne transakcije i zajedničke brave | N-09 |
| P-07 | Predvidljiv token obnove lozinke omogućuje preuzimanje tuđeg računa | 3 | 3 | 9 | Odgovor ne otkriva postoji li korisnik; nova lozinka mora imati najmanje osam znakova | Token generirati kriptografski sigurnim slučajnim generatorom `secrets.token_urlsafe()` | N-01 |
| P-08 | Lozinka, OIB i razlog godišnjeg odmora zapisuju se u log | 3 | 2 | 6 | Aplikacija ima centralizirano logiranje i klijentu vraća generičke poruke za neočekivane greške | Logirati samo korisničko ime i vrstu događaja, bez lozinki i osobnih podataka | N-08 |
| P-09 | Nepoznat format platne liste preskače provjeru vlasništva i otkriva tuđu listu | 3 | 3 | 9 | Endpoint traži prijavu, dohvaća zapis iz baze i ima provjeru vlasništva, ali ona se izvršavala tek nakon obrade formata | Provjeru autorizacije izvršiti prije parsiranja formata i prije operacije koja može baciti iznimku | N-04 |
## 5. Zaključak

*Koje prijetnje su se pokazale stvarnim ranjivostima, koje su bile dobro zaštićene i što bi model trebao
uključivati u budućim verzijama aplikacije.*

Model prijetnji pokazao je da su najvrjednija imovina korisnički računi, tokeni i osobni podaci. 
Najveći rizici bili su povezani s otkrivanjem informacija, lažnim predstavljanjem i podizanjem ovlasti. 
Ručnim pregledom i alatima potvrđene su prijetnje path traversala, SQL injectiona, XXE-a, stored XSS-a, 
predvidljivog tokena obnove lozinke, slabog hashiranja, race conditiona, osjetljivih podataka u logu i fail-open autorizacije. 
Ispravno su već bili implementirani parametrizirani upiti u većini sustava, generičke poruke pogrešaka, CORS allowlist, 
provjera lokalnog returnUrl odredišta i autorizacija pojedinih objekata. 
Buduće verzije trebale bi uključiti TLS/HSTS, CSP, zaštitu od clickjackinga, istek i jednokratnu uporabu reset tokena 
te centralizirani sigurnosni nadzor.
